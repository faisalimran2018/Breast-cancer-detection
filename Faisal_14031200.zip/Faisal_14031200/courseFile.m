
% Reading data file 
data = load('withMean.data');
inputData  = data(:,2:10);
outputData  = data(:,11);
test = data(:,2:10);

%mean = data(:,7);
%addition = sum(mean);
% addition  = addition/length(mean);

% Creating Network 
net = newff(inputData',outputData',1, {'tansig' 'tansig'}, 'trainr', 'learngd', 'mse');
net.trainParam.goal = 0.01;
net.trainParam.epochs = 100;
net.trainParam.max_fail=10;
view(net);
% Training Network
net = train(net, inputData',outputData');

% Result of network/ Tesing Network on input
result = net(test');
result = result';

sizeResult = size(result);
num = sizeResult(1,1);

% Post Processing on result
count=0;
i= 1;
for i = 1:num
    if(result(i,1)>=3)
        if(outputData(i,1)==2)
            count = count+1;
        end
    else
        if(result(i,1)==4)
            count = count+1;
        end
            
    end
end

matched = num - count;

% Calculating Performance
performance = matched/num*100;
disp(performance);




    